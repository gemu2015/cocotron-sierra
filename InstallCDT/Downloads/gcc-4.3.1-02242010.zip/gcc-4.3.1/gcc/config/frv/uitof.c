float __uitof (unsigned int a)
{
  return a;
}
