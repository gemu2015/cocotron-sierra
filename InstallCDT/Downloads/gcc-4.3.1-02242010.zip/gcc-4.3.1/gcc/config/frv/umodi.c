unsigned int __umodi (unsigned int a, unsigned int b)
{
  return a % b;
}
